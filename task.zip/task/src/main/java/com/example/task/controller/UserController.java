package com.example.task.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.task.model.User;
import com.example.task.serrvice.UserService;

@RestController
public class UserController {
	public static final Logger logger=LoggerFactory.getLogger(UserController.class);

	@Autowired
	private UserService userService;
	
	@GetMapping("/users")
	public ResponseEntity<List<User>> getAllUsers(){
		return ResponseEntity.ok().body(userService.getAllUsers());
	}
	
	@GetMapping("/users/{userid}")
	public ResponseEntity<User> getUserById(@PathVariable Integer userid) {
		logger.info("Fetching User with id {}",userid);
		return ResponseEntity.ok().body(userService.getUserById(userid));
	}
	@PostMapping("/users")
	public ResponseEntity<User> Save(@RequestBody User user){
		logger.info("create user",user);
		return ResponseEntity.ok().body(userService.save(user));
		
	}
	@PutMapping("/users/{userid}")
	public ResponseEntity<User> updateUser(@PathVariable Integer userid,@RequestBody User user){
		logger.info("update user with id",userid);
		user.setUserid(userid);
		return ResponseEntity.ok().body(userService.updateUser(user));
		
	}
	@DeleteMapping("/users/{userid}")
	public HttpStatus deleteUser(@PathVariable Integer userid) {
		logger.info("fetching&Deleting user with id",userid);
		this.userService.deleteUserId(userid);
		return HttpStatus.OK;
}
}
