package com.example.task.serrvice;

import java.util.List;

import com.example.task.model.User;

public interface UserService {
	
	public  User save(User user);

	  public User updateUser(User user);
	  
	  public User getUserById(Integer id);
	  
	  List<User> getAllUsers();
	  
	  public void deleteUserId(Integer id);
	    

}
