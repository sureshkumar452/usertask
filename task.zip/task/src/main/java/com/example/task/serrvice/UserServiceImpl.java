package com.example.task.serrvice;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.example.task.dao.UserRepository;
import com.example.task.model.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository UserRepository;


	@Override
	public User save(User user) {
		
		return UserRepository.save(user);
	}

	@Override
	public User updateUser(User user) {
		Optional<User> users=this.UserRepository.findById(user.getUserid());
		if(users.isPresent()) {
		User user2=users.get();
		user2.setUserid(user.getUserid());
		user2.setUsername(user.getUsername());
		user2.setEmail(user.getEmail());
		user2.setPassword(user.getPassword());
		
		}else {
			throw new UsernameNotFoundException("Record not found with id:"+user.getUserid());
		}
		return user;
	
	}

	@Override
	public User getUserById(Integer userid) {
		Optional<User> users=this.UserRepository.findById(userid);
		if(users.isPresent()) {
			return users.get();
		}else {
			throw new UsernameNotFoundException("Record not found with id:"+userid);
		}
		
		
		
	}

	@Override
	public List<User> getAllUsers() {
		
		return this.UserRepository.findAll();
	}

	@Override
	public void deleteUserId(Integer userid) {
		Optional<User> users=this.UserRepository.findById(userid);
		if(users.isPresent()) {
			this.UserRepository.delete(users.get());
		}else {
			throw new UsernameNotFoundException("Record not found with id:"+userid);
			
		}
		
	}

}
