package com.example.task.util;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.example.task.model.User;


@Service
public class EmailUtil {

	@Autowired
	private JavaMailSender emailSender;

	public void sendSimpleMessage(Mail mail) throws MessagingException {

		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);

		helper.setSubject(mail.getSubject());
		helper.setText(mail.getContent(),true);
		helper.setTo(mail.getTo());
		helper.setFrom(mail.getTo());

		// helper.addAttachment("attachment-document-name.jpg", new
		// ClassPathResource("memorynotfound-logo.jpg"));

//        helper.addAttachment("text.docx", new ClassPathResource("text.docx"));
		emailSender.send(message);

	}

	public void sendUserLoginDetails(User user,String userDisplayName,String password) {

		StringBuffer msg = new StringBuffer();
		msg.append("<h4>Registration confirmation</h4>");
		msg.append("<p>Hi "+userDisplayName+", Your are registerd with user system, please find below login credentials to access this system.<p>");
		msg.append("<table>\n" + 
				"    <tr>\n" + 
				"        <td>UserId</td>\n" + 
				"        <td>"+user.getUsername()+"</td>\n" + 
				"    </tr>\n" + 
				"    <tr>\n" + 
				"        <td>Password</td>\n" + 
				"        <td>"+password+"</td>\n" + 
				"    </tr>\n" + 
				"</table>");

		    Mail mail = new Mail();
	        mail.setFrom("no-reply@trackar.com");
	        mail.setTo(user.getEmail());
	        mail.setSubject("User login credentials to access user!");
	        mail.setContent(msg.toString());
	       try {
			sendSimpleMessage(mail);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

}
